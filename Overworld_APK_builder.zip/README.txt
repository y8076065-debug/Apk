Overworld APK builder
1. Create a free GitHub repository and upload everything in this folder (keep .github and www).
2. Open the repo > Actions > "Build APK" > Run workflow.
3. When it finishes (about 5 minutes), open the run and download the "overworld-apk" artifact.
4. Unzip it, open app-debug.apk on your phone and allow "install unknown apps" if asked.
This is an unsigned debug build for personal use.
